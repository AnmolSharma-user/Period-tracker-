export interface User {
  id: string;
  email: string;
  age: number;
  cycleLength: number;
  lastPeriod: string;
  regularCycle: boolean;
}

export interface CycleData {
  id: string;
  userId: string;
  date: string;
  symptoms: string[];
  intensity: Record<string, number>;
  notes?: string;
}

export interface CyclePhase {
  phase: string;
  fertility: string;
  recommendations: {
    exercise: string;
    diet: string;
    mood: string;
  };
}