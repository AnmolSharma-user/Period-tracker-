import React, { useState } from 'react';
import { Activity, Plus } from 'lucide-react';
import { useUserStore } from '../store/userStore';

const commonSymptoms = [
  'Cramps', 'Headache', 'Bloating', 'Fatigue',
  'Mood Swings', 'Breast Tenderness', 'Back Pain',
  'Acne', 'Food Cravings', 'Insomnia'
];

export default function SymptomTracker() {
  const addCycleData = useUserStore((state) => state.addCycleData);
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [intensity, setIntensity] = useState<Record<string, number>>({});
  const [customSymptom, setCustomSymptom] = useState('');
  const [notes, setNotes] = useState('');

  const toggleSymptom = (symptom: string) => {
    setSelectedSymptoms(prev => 
      prev.includes(symptom)
        ? prev.filter(s => s !== symptom)
        : [...prev, symptom]
    );
    
    if (!intensity[symptom]) {
      setIntensity(prev => ({ ...prev, [symptom]: 1 }));
    }
  };

  const handleIntensityChange = (symptom: string, value: number) => {
    setIntensity(prev => ({ ...prev, [symptom]: value }));
  };

  const addCustomSymptom = (e: React.FormEvent) => {
    e.preventDefault();
    if (customSymptom && !commonSymptoms.includes(customSymptom)) {
      toggleSymptom(customSymptom);
      setCustomSymptom('');
    }
  };

  const handleSubmit = async () => {
    try {
      await addCycleData({
        date: new Date().toISOString(),
        symptoms: selectedSymptoms,
        intensity,
        notes,
      });

      // Reset form
      setSelectedSymptoms([]);
      setIntensity({});
      setNotes('');
      
      alert('Symptoms logged successfully!');
    } catch (error) {
      console.error('Error:', error);
      alert('Failed to log symptoms. Please try again.');
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-6">
      <div className="flex items-center mb-6">
        <Activity className="w-6 h-6 text-pink-500 mr-2" />
        <h2 className="text-2xl font-bold text-gray-800">Symptom Tracker</h2>
      </div>

      <div className="space-y-6">
        <div className="flex flex-wrap gap-2">
          {commonSymptoms.map(symptom => (
            <button
              key={symptom}
              onClick={() => toggleSymptom(symptom)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                selectedSymptoms.includes(symptom)
                  ? 'bg-pink-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {symptom}
            </button>
          ))}
        </div>

        <form onSubmit={addCustomSymptom} className="flex gap-2">
          <input
            type="text"
            value={customSymptom}
            onChange={(e) => setCustomSymptom(e.target.value)}
            placeholder="Add custom symptom..."
            className="flex-1 rounded-lg border-gray-300 focus:border-pink-500 focus:ring-pink-500"
          />
          <button
            type="submit"
            className="bg-pink-500 text-white rounded-lg px-4 py-2 hover:bg-pink-600 transition-colors"
          >
            <Plus className="w-5 h-5" />
          </button>
        </form>

        {selectedSymptoms.length > 0 && (
          <div className="space-y-4">
            <h3 className="font-medium text-gray-700">Symptom Intensity</h3>
            {selectedSymptoms.map(symptom => (
              <div key={symptom} className="space-y-2">
                <div className="flex justify-between">
                  <span>{symptom}</span>
                  <span className="text-gray-500">
                    {intensity[symptom] || 1}/5
                  </span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="5"
                  value={intensity[symptom] || 1}
                  onChange={(e) => handleIntensityChange(symptom, Number(e.target.value))}
                  className="w-full"
                />
              </div>
            ))}

            <div className="space-y-2">
              <label className="block font-medium text-gray-700">Notes</label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Add any additional notes..."
                className="w-full rounded-lg border-gray-300 focus:border-pink-500 focus:ring-pink-500"
                rows={3}
              />
            </div>

            <button
              onClick={handleSubmit}
              className="w-full bg-pink-500 text-white rounded-lg py-2 hover:bg-pink-600 transition-colors"
            >
              Log Symptoms
            </button>
          </div>
        )}
      </div>
    </div>
  );
}