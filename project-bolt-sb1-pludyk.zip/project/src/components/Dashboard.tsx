import React, { useState, useEffect } from 'react';
import { Calendar as CalendarIcon, Moon, Sun, Heart, Activity } from 'lucide-react';
import Calendar from 'react-calendar';
import { format, addDays, differenceInDays } from 'date-fns';
import { useUserStore } from '../store/userStore';
import ChatAssistant from './ChatAssistant';
import SymptomTracker from './SymptomTracker';

export default function Dashboard() {
  const { cycleData } = useUserStore();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [cycleInfo, setCycleInfo] = useState({
    phase: '',
    fertility: '',
    symptoms: [],
    recommendations: {}
  });

  useEffect(() => {
    calculateCycleInfo(selectedDate);
  }, [selectedDate]);

  const calculateCycleInfo = (date: Date) => {
    const dayInCycle = differenceInDays(date, new Date(cycleData?.lastPeriod || Date.now())) % (cycleData?.cycleLength || 28);
    
    let phase = '';
    let fertility = '';
    let recommendations = {
      exercise: '',
      diet: '',
      mood: ''
    };

    if (dayInCycle <= 5) {
      phase = 'Menstrual';
      fertility = 'Low';
      recommendations = {
        exercise: 'Light exercises like walking or yoga',
        diet: 'Iron-rich foods and warm, comforting meals',
        mood: 'Take it easy and practice self-care'
      };
    } else if (dayInCycle <= 14) {
      phase = 'Follicular';
      fertility = 'High';
      recommendations = {
        exercise: 'High-intensity workouts',
        diet: 'Protein-rich foods and fresh vegetables',
        mood: 'Great time for new projects and social activities'
      };
    }

    setCycleInfo({ phase, fertility, symptoms: [], recommendations });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-8">
            <div className="bg-white rounded-2xl shadow-xl p-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
                <CalendarIcon className="w-6 h-6 mr-2 text-pink-500" />
                Cycle Calendar
              </h2>
              <Calendar
                onChange={setSelectedDate}
                value={selectedDate}
                className="rounded-lg border-none shadow-sm"
              />
            </div>

            <div className="bg-white rounded-2xl shadow-xl p-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
                <Moon className="w-6 h-6 mr-2 text-pink-500" />
                Cycle Phase
              </h2>
              <div className="space-y-4">
                <p className="text-lg font-medium">Current Phase: {cycleInfo.phase}</p>
                <p className="text-lg font-medium">Fertility: {cycleInfo.fertility}</p>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-xl p-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
                <Heart className="w-6 h-6 mr-2 text-pink-500" />
                Daily Recommendations
              </h2>
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium text-gray-700">Exercise</h3>
                  <p className="text-gray-600">{cycleInfo.recommendations.exercise}</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-700">Diet</h3>
                  <p className="text-gray-600">{cycleInfo.recommendations.diet}</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-700">Mood & Energy</h3>
                  <p className="text-gray-600">{cycleInfo.recommendations.mood}</p>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <SymptomTracker />
            <ChatAssistant />
          </div>
        </div>
      </div>
    </div>
  );
}