import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, Heart, Activity } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useUserStore } from '../store/userStore';

interface OnboardingData {
  age: string;
  cycleLength: number;
  lastPeriod: string;
  regularCycle: boolean;
}

export default function OnboardingForm() {
  const navigate = useNavigate();
  const setUser = useUserStore((state) => state.setUser);
  const [step, setStep] = useState(1);
  const [data, setData] = useState<OnboardingData>({
    age: '',
    cycleLength: 28,
    lastPeriod: '',
    regularCycle: true,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      // First, sign up anonymously
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: `${Math.random().toString(36).slice(2)}@anonymous.com`,
        password: Math.random().toString(36).slice(2),
      });

      if (authError) throw authError;

      // Then, create the user profile
      const { data: userData, error: userError } = await supabase
        .from('users')
        .insert([
          {
            id: authData.user?.id,
            ...data,
          },
        ])
        .select()
        .single();

      if (userError) throw userError;

      setUser(userData);
      navigate('/dashboard');
    } catch (error) {
      console.error('Error:', error);
      alert('Failed to create profile. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full">
        <div className="text-center mb-8">
          <Heart className="w-12 h-12 text-pink-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-800">Welcome to Luna</h1>
          <p className="text-gray-600">Let's personalize your experience</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Your Age</label>
                <input
                  type="number"
                  value={data.age}
                  onChange={(e) => setData({ ...data, age: e.target.value })}
                  min="8"
                  max="80"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-pink-500 focus:ring-pink-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Regular Cycle?</label>
                <select
                  value={data.regularCycle.toString()}
                  onChange={(e) => setData({ ...data, regularCycle: e.target.value === 'true' })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-pink-500 focus:ring-pink-500"
                >
                  <option value="true">Yes</option>
                  <option value="false">No</option>
                </select>
              </div>
              <button
                type="button"
                onClick={() => setStep(2)}
                className="w-full bg-pink-500 text-white rounded-lg py-2 hover:bg-pink-600 transition-colors"
              >
                Next
              </button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Last Period Start Date</label>
                <input
                  type="date"
                  value={data.lastPeriod}
                  onChange={(e) => setData({ ...data, lastPeriod: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-pink-500 focus:ring-pink-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Average Cycle Length</label>
                <input
                  type="number"
                  value={data.cycleLength}
                  onChange={(e) => setData({ ...data, cycleLength: parseInt(e.target.value) })}
                  min="21"
                  max="35"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-pink-500 focus:ring-pink-500"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full bg-pink-500 text-white rounded-lg py-2 hover:bg-pink-600 transition-colors"
              >
                Complete Setup
              </button>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}