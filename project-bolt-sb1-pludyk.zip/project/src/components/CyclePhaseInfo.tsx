import React from 'react';
import { Moon, Sun, Heart } from 'lucide-react';
import { calculateCyclePhase, getFertilityStatus, getPhaseRecommendations } from '@/lib/utils';

interface CyclePhaseInfoProps {
  lastPeriod: string;
  cycleLength: number;
}

export default function CyclePhaseInfo({ lastPeriod, cycleLength }: CyclePhaseInfoProps) {
  const phase = calculateCyclePhase(lastPeriod, cycleLength);
  const fertility = getFertilityStatus(phase);
  const recommendations = getPhaseRecommendations(phase);

  return (
    <div className="bg-white rounded-2xl shadow-xl p-6">
      <div className="flex items-center mb-4">
        <Moon className="w-6 h-6 text-pink-500 mr-2" />
        <h2 className="text-2xl font-bold text-gray-800">Cycle Phase</h2>
      </div>
      
      <div className="space-y-6">
        <div>
          <p className="text-lg font-medium">Current Phase: 
            <span className="ml-2 text-pink-500 capitalize">{phase}</span>
          </p>
          <p className="text-lg font-medium">Fertility: 
            <span className="ml-2 text-pink-500 capitalize">{fertility}</span>
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <h3 className="font-medium text-gray-700 flex items-center">
              <Activity className="w-4 h-4 mr-2" />
              Exercise
            </h3>
            <p className="text-gray-600 mt-1">{recommendations.exercise}</p>
          </div>

          <div>
            <h3 className="font-medium text-gray-700 flex items-center">
              <Apple className="w-4 h-4 mr-2" />
              Diet
            </h3>
            <p className="text-gray-600 mt-1">{recommendations.diet}</p>
          </div>

          <div>
            <h3 className="font-medium text-gray-700 flex items-center">
              <Heart className="w-4 h-4 mr-2" />
              Mood & Energy
            </h3>
            <p className="text-gray-600 mt-1">{recommendations.mood}</p>
          </div>
        </div>
      </div>
    </div>
  );
}