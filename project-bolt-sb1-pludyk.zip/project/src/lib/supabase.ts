import { createClient } from '@supabase/supabase-js';

export const supabase = createClient(
  'https://thqbhnkdmnfxgifajzvy.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRocWJobmtkbW5meGdpZmFqenZ5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDg2ODg5NDAsImV4cCI6MjAyNDI2NDk0MH0.xDUoQz6ZJG-NxFtj7TfGQPG9fmZUCYJ3mQhvGnFVL8Y'
);