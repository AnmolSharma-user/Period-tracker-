import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function calculateCyclePhase(lastPeriod: string, cycleLength: number): string {
  const today = new Date();
  const lastPeriodDate = new Date(lastPeriod);
  const daysSinceLastPeriod = Math.floor((today.getTime() - lastPeriodDate.getTime()) / (1000 * 60 * 60 * 24));
  const currentCycleDay = daysSinceLastPeriod % cycleLength;

  if (currentCycleDay <= 5) return 'menstrual';
  if (currentCycleDay <= 10) return 'follicular';
  if (currentCycleDay <= 14) return 'ovulatory';
  return 'luteal';
}

export function getFertilityStatus(phase: string): string {
  switch (phase) {
    case 'ovulatory':
      return 'high';
    case 'follicular':
      return 'medium';
    default:
      return 'low';
  }
}

export function getPhaseRecommendations(phase: string) {
  const recommendations = {
    menstrual: {
      exercise: 'Light exercises like walking or gentle yoga',
      diet: 'Iron-rich foods, warm soups, and anti-inflammatory foods',
      mood: 'Rest and self-care are important during this phase'
    },
    follicular: {
      exercise: 'High-intensity workouts and strength training',
      diet: 'Protein-rich foods and fresh vegetables',
      mood: 'Great time for starting new projects and socializing'
    },
    ovulatory: {
      exercise: 'Dance, cardio, and group activities',
      diet: 'Light, nutrient-dense foods and plenty of water',
      mood: 'Peak energy levels - ideal for important meetings and events'
    },
    luteal: {
      exercise: 'Moderate exercise like swimming or pilates',
      diet: 'Complex carbs and magnesium-rich foods',
      mood: 'Focus on completing tasks and winding down'
    }
  };

  return recommendations[phase as keyof typeof recommendations];
}