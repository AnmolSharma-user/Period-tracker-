import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User, CycleData } from '../types';
import { supabase } from '../lib/supabase';

interface UserState {
  user: User | null;
  cycleData: CycleData[];
  setUser: (user: User | null) => void;
  addCycleData: (data: Omit<CycleData, 'id' | 'userId'>) => Promise<void>;
  getCycleData: () => Promise<void>;
}

export const useUserStore = create<UserState>()(
  persist(
    (set, get) => ({
      user: null,
      cycleData: [],
      setUser: (user) => set({ user }),
      addCycleData: async (data) => {
        const { user } = get();
        if (!user) return;

        const { data: newData, error } = await supabase
          .from('cycle_data')
          .insert([
            {
              userId: user.id,
              ...data,
            },
          ])
          .select()
          .single();

        if (error) throw error;

        set((state) => ({
          cycleData: [...state.cycleData, newData],
        }));
      },
      getCycleData: async () => {
        const { user } = get();
        if (!user) return;

        const { data, error } = await supabase
          .from('cycle_data')
          .select('*')
          .eq('userId', user.id)
          .order('date', { ascending: false });

        if (error) throw error;

        set({ cycleData: data });
      },
    }),
    {
      name: 'user-storage',
    }
  )
);